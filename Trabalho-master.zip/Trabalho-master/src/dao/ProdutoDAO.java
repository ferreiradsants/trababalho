/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;
import  factory.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import modelo.produto;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
/**
 *
 * @author gabym
 */
public class ProdutoDAO {
    private Connection connection;
    String nome,tipo,cor,material;
    boolean emprestado;
     public ProdutoDAO() {
        this.connection = new ConnectionFactory().getConnection();
    }
    public void adiciona(produto P){
        String consulta = "INSERT INTO caracteristicas(nome,tipo,material,cor) VALUES(?,?,?,?)";
        try{
        PreparedStatement stmt = connection.prepareStatement(consulta);
        stmt.setString(1, P.getNome());
        stmt.setString(2, P.getTipo());
        stmt.setString(3, P.getMaterial());
        stmt.setString(4, P.getCor());
        stmt.execute();
        stmt.close();}
        catch(SQLException u){
            throw new RuntimeException(u);
        }
    }
    public List<produto> recuperar()
    { 
        List<produto> produtos = new ArrayList<>();
        String consulta ="SELECT * FROM CARACTERISTICAS" ;
        //ResultSet é uma classe que é utilizada para  armazenar o retorno das consultas
        ResultSet  rs= null; // Armazena o retorno da cosulta
        
        try{
         PreparedStatement stmt = connection.prepareStatement(consulta);
         rs = stmt.executeQuery();// Armazena o retorno da cosulta
         while(rs.next()) //retorna todos os registros do banco
         {
             produto p = new produto();
             p.setNome(rs.getString("nome"));
             p.setTipo(rs.getString("tipo"));
             p.setMaterial(rs.getString("material"));
             p.setCor(rs.getString("cor"));
             produtos.add(p);
         }   
         }catch (SQLException u) { 
            JOptionPane.showMessageDialog(null,"Erro ao recuperar dados " + u );
            throw new RuntimeException(u);
        }
         return produtos;
    
    }
}
